import cv2
import numpy as np
import serial
import time

arduino_serial = serial.Serial('/dev/ttyAMA0', 9600, timeout=1)
arduino_serial.flush()

# Hu Moments of a reference object (adjust as needed)
reference_hu_moments = np.array([0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8])

def detect_color(frame):
    # Convert the frame to the HSV color space
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Define the color ranges for green in HSV format
    green_low = np.array([35, 100, 100])
    green_high = np.array([85, 255, 255])

    # Define the color ranges for red in HSV format
    red_low = np.array([0, 100, 100])
    red_high = np.array([10, 255, 255])

    # Define the color ranges for yellow in HSV format
    yellow_low = np.array([20, 100, 100])
    yellow_high = np.array([30, 255, 255])

    # Create masks for each of the colors
    green_mask = cv2.inRange(hsv_frame, green_low, green_high)
    red_mask = cv2.inRange(hsv_frame, red_low, red_high)
    yellow_mask = cv2.inRange(hsv_frame, yellow_low, yellow_high)

    # Find contours in the masks
    green_contours, _ = cv2.findContours(green_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    red_contours, _ = cv2.findContours(red_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    yellow_contours, _ = cv2.findContours(yellow_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Check if any of the colors were detected
    if len(red_contours) > 0:
        return "R"
    elif len(yellow_contours) > 0:
        return "Y"
    elif len(green_contours) > 0:
        return "G"
    else:
        return ""

def detect_letter(frame):
    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Apply a threshold to segment black objects
    _, thresholded = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY)

    # Invert the colors so that objects are white and background is black
    thresholded_inverted = cv2.bitwise_not(thresholded)

    # Find contours in the binary image
    contours, _ = cv2.findContours(thresholded_inverted, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Initialize a list to store the calculated Hu Moments
    hu_moments_list = []

    for contour in contours:
        # Calculate Hu Moments from the contour
        moments = cv2.moments(contour)
        hu_moments = cv2.HuMoments(moments).flatten()

        # Add the Hu Moments to the list
        hu_moments_list.append(hu_moments)

    if hu_moments_list:
        # Calculate the average of the Hu Moments from the list
        avg_hu_moments = np.mean(hu_moments_list, axis=0)

        # Calculate the difference between the average Hu Moments and the reference object
        difference = np.abs(avg_hu_moments - reference_hu_moments).sum()

        # Round the difference to 2 decimal places
        rounded_difference = round(difference, 2)

        # Check if the current value falls within specified ranges
        if rounded_difference > 3.50:
            return "Letter"
        else:
            return ""

width = 320
height = 240

# Initialize video capture from webcam
cap = cv2.VideoCapture(0)

# Set the width and height of frames
cap.set(3, width)  # Code 3 corresponds to frame width identifier
cap.set(4, height)  # Code 4 corresponds to frame height identifier

cap.set(cv2.CAP_PROP_FPS, 30)  # Set frame rate to 30 FPS

while True:
    character = arduino_serial.read().decode('utf-8')

    # Capture a video frame
    ret, frame = cap.read()

    if not ret:
        print("Error capturing frame.")
        break

    # Display the frame with contours
    cv2.imshow('Colors and Letters', frame)

    # Check if 'q' key is pressed to exit the loop
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    
    if character == 'L':
        color_result = detect_color(frame)
        letter_result = detect_letter(frame)

        # Read the information
        if color_result:
            print(color_result)
            arduino_serial.write(color_result.encode('utf-8'))
        if letter_result:
            print(letter_result)
            arduino_serial.write(letter_result.encode('utf-8'))
        if not color_result and not letter_result:
            print("X")  # Send "X" if no color or letter is detected
            arduino_serial.write(b"X\n")

# Release video capture and close window
cap.release()
cv2.destroyAllWindows()